<?php
require('db_connect.php');
require('setup.php');

echo '<div id="formsection">';
echo '<h1> hello Obanshire Cub Scouts.</h1>';
include('display_event_form.php');


echo '</div>';






require('footer.php');
?>