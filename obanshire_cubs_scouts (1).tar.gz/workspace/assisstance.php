<?php
require('setup.php');

echo'
<div id="events">

<h2>INTERNATIONAL OBANSHIRE CUB SCOUTS.</h2>

<div id="We arer celebrating our 200 years OBANSHIRE CUB SCOUTS great services">



<div class="container">

  <div class="demo-section">
    
  </div>

  <div class="tab-wrap">
    
    <!-- active tab on page load gets checked attribute -->
    <input type="radio" id="tab1" name="tabGroup1" class="tab" checked>
    <label for="tab1">FIRST EVENT</label>

    <input type="radio" id="tab2" name="tabGroup1" class="tab">
    <label for="tab2">SECOUNT EVENT</label>

    <input type="radio" id="tab3" name="tabGroup1" class="tab">
    <label for="tab3">THIRD EVENT</label>

    <div class="tab__content">
      <h3>MICKEY MOUSE</h3>
      <p>Our Obanshire Cub Scouts centre allows everyone to attend our 200 years best provided services and we would like you to attend and participate paint our Mickey Mouse, anyone who is intersted in to draw Mickey Mouse then please be a part of our champion to fight against your opposation.</p>
    </div>

    <div class="tab__content">
      <h3>SANTA</h3>
      <p>.</p>

      <p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Morbi mattis ullamcorper velit. Pellentesque posuere. Etiam ut purus mattis mauris sodales aliquam. Praesent nec nisl a purus blandit viverra.</p>
    </div>

    <div class="tab__content">
      <h3>Tom and Jerry</h3>
      <p>We will arange the time for Tom and Jerry to come along with Mr Santa to attend the OBANSHIRE 10 best workers concert on 23/08/2016.</p>

      
    </div>

  </div>

  <div class="demo-section">
    <p>Donec interdum, metus et hendrerit aliquet, dolor diam sagittis ligula, eget egestas libero turpis vel mi. Proin viverra, ligula sit amet ultrices semper, ligula arcu tristique sapien, a accumsan nisi mauris ac eros. Phasellus volutpat, metus eget
      egestas mollis, lacus lacus blandit dui, id egestas quam mauris ut lacus. Praesent nec nisl a purus blandit viverra. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>

    <p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Morbi mattis ullamcorper velit. Pellentesque posuere. Etiam ut purus mattis mauris sodales aliquam. Praesent nec nisl a purus blandit viverra.</p>
  </div>

  <div class="tab-wrap">

    <input type="radio" id="tab4" name="tabGroup2" class="tab" checked>
    <label for="tab4">Apples</label>

    <input type="radio" id="tab5" name="tabGroup2" class="tab">
    <label for="tab5">Oranges</label>

    <input type="radio" id="tab6" name="tabGroup2" class="tab">
    <label for="tab6">Bananas</label>

    <input type="radio" id="tab7" name="tabGroup2" class="tab">
    <label for="tab7">Kiwis</label>

    <input type="radio" id="tab8" name="tabGroup2" class="tab">
    <label for="tab8">Tomatos</label>

    <div class="tab__content">
      <h3>Apples</h3>
      <p>Praesent nonummy mi in odio. Nullam accumsan lorem in dui. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam accumsan lorem in dui. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
    </div>

    <div class="tab__content">
      <h3>Oranges</h3>
      <p>Praesent nonummy mi in odio. Nullam accumsan lorem in dui. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam accumsan lorem in dui. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>

      <p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Morbi mattis ullamcorper velit. Pellentesque posuere. Etiam ut purus mattis mauris sodales aliquam. Praesent nec nisl a purus blandit viverra.</p>
    </div>

    <div class="tab__content">
      <h3>Bananas</h3>
      <p>Praesent nonummy mi in odio. Nullam accumsan lorem in dui. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam accumsan lorem in dui. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
    </div>

    <div class="tab__content">
      <h3>Kiwis</h3>
      <p>Praesent nonummy mi in odio.</p>
    </div>

    <div class="tab__content">
      <h3>Tomatos</h3>
      <p>Praesent nonummy mi in odio. Nullam accumsan lorem in dui. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum.</p>
    </div>

  </div>

  <div class="demo-section">
    <p>Etiam ut purus enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Morbi mattis ullamcorper velit. Pellentesque posuere. Etiam ut purus mattis mauris sodales aliquam. Praesent nec nisl a purus blandit viverra.</p>

    <p>Praesent nonummy mi in odio. Nullam accumsan lorem in dui. Vestibulum turpis sem, aliquet eget, lobortis pellentesque, rutrum eu, nisl. Nullam accumsan lorem in dui. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>
  </div>

</div>
</div><!--end of content-form-->
';
?>