<?php
require('db_connect.php');
require('setup.php');

echo '<h3> Delete events</h3>';

echo '<form name="eventdelete" action="delete_event.php" method="post">
Field: <select name="field">
	<option value="id">id</option>
	<option value="name">name</option>
	<option value="info">info</option>
	<option value="path">image</option>
	
	</select>
	
Value: <input type="text" name="input_value">
<input type="submit" name="submit">
</form>';



require('footer.php');
?>