<?php
require('db_connect.php');
require('setup.php');


echo '<h2>Editing a Badge</h2>';
require('eventsearch.php');
if(mysql_num_rows($result) ==1){
 echo' What changes do you want to make?';
echo'<form action="editfinal.php" method="POST">
<input type="hidden" name="input_value=" value="' .$input_value.'">
<input type="hidden" name="field" value="' .$field.'">
Name: <input name="name" type="text">
Information: <input name="info" type="text">
Image: <input name="path" type="text">
<input type="Submit" name="submit">
</form>';
}
else{
 echo '<p>MUltiple or no results. Please try again</p>';
 echo '<a href="login.php">Back to main page</a>';
}
 


require('footer.php');
?>