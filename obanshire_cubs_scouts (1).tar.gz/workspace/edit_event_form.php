<?php
require('db_connect.php');
require('setup.php');

echo '<h1>Editing events</h1>';
if(isset($_POST['Submit'])){
    $field= mysql_escape_string($_POST['field']);
    $input_value=mysql_escape_string($_POST['input_value']);
    
    $title= mysql_escape_string($_POST['title']);
    $description= mysql_escape_string($_POST['description']);
     $date= mysql_escape_string($_POST['date']);
    $location= mysql_escape_string($_POST['location']);
    echo $field;
    $sql = "UPDATE events SET title='$title',description='$description',date='$date' ,location='$location' WHERE $field='$input_value'";
$result=mysql_query($sql);
echo'<a href="modify.php">Login</a>';
}




require('footer.php');
?>