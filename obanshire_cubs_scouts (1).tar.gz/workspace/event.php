<?php
require('db_connect.php');
require('setup.php');











require('footer.php')
?>