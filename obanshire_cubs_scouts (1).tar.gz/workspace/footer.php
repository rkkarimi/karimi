<?php

echo'<div id="footer">
<p class="subtle">All Content &copy; 2016</p>
</div><!--end of footer-->

</div><!--end of container-->
</body>
</html>';

?>