<?php
require('setup.php');
require('db_connect.php');

echo'
<div id="hang">

<h2>This is hangman page.</h2>

<div id="play">



</div>

</div><!--end of content-form-->





';
require('footer.php');

?>