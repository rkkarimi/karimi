<?php


require('setup.php');
echo'

<div id="content-form">

<h1>helper query page.</h1>

<div id="contactDetails">



</div>

</div>


';

?>