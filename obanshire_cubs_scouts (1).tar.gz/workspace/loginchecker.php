<?php
if(!$_SESSION['login']=="1"){
	header("Location: generate.php");
}
?>