<?php
require('setup.php');
require('db_connect.php');

echo'
<div id="matching">

<h2>This is matching game page.</h2>

<div id="match">



</div>

</div><!--end of content-form-->
';

require('footer.php');

?>