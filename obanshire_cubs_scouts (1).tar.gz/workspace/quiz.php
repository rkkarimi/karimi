<?php
require('setup.php');

echo'
<div id="content-form">

<h2>This is quiz page.</h2>

<div id="quiz">
<table>
	<tr>
		<th colspan="3">Quiz</th>
	</tr>
    <tr>
    	
    </tr>
</table>


</div>

</div><!--end of content-form-->

';
















require('footer.php');

?>