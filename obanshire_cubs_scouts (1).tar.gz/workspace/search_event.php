<?php
require('db_connect.php');
require('setup.php');

echo'<h1>search event</h1>';

require('eventsearch.php');
echo'<a href="badge.php">back to badge page</a>';

require('footer.php');
?>

