upload.php

<?php
include 'db_connect.php';
//must be changed to be your directory
$target_dir = "images/";
//target file variable will be input into the database as the photo
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$title= mysql_escape_string($_POST['title']);
$description= mysql_escape_string($_POST['description']);
$date = mysql_escape_string($_POST['date']);
$location= mysql_escape_string($_POST['location']);

$image= $target_file;
$sql = "INSERT INTO event ( title, description, date, location, image)
VALUES ('$title', '$description', '$date' ,'$fuel','$location','$image' )";


if (mysql_query($sql)) {
 echo "New record created successfully";
} else {
 echo "Error: " . $sql . "<br>" . mysql_error($conn);
}
//COPY THIS CODE
/*ALL OF THE FOLLOWING CODE INVOLVES CHECKING AND UPLOADING THE FILE*/
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
 $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
 if($check !== false) {
 echo "File is an image - " . $check["mime"] . ".";
 $uploadOk = 1;
 } else {

 echo "File is not an image.";
 $uploadOk = 0;
 }
}
// Check if file already exists
if (file_exists($target_file)) {
 echo "Sorry, file already exists.";
 $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
 echo "Sorry, your file is too large.";
 $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
 echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
 $uploadOk = 0;

}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
 echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
 if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
 echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
 } else {
 echo "Sorry, there was an error uploading your file.";
 }
}
echo '<a href="generate.php"> Back to main page</a>';
//END OF COPIED CODE
require('footer.php');
?>

